#pragma once

#define MAX_LEN 20

void print_triangle(unsigned int tr[][MAX_LEN], size_t len);
void pascal_triangle(unsigned int tr[][MAX_LEN], size_t len);
