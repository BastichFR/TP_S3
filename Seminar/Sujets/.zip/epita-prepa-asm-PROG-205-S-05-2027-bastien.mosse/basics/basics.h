#pragma once

size_t str_chr(char s[], char c);
void str_cat(char s1[], char s2[]);
int str_cmp(char s1[], char s2[]);
unsigned int str_toui(char s[]);
void rm_chr(char c, char s[]);
