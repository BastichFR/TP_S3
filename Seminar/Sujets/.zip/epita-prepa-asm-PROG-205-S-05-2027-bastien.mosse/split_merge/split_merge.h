#pragma once

#define MAX_WORD 20
#define MAX_CHAR 20

void split(char s[], char words[][MAX_CHAR]);
void merge(char s[], size_t argc, char** argv);
