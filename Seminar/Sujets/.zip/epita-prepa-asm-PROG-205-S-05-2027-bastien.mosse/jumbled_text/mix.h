#ifndef MIX_H
#define MIX_H

void mix(char s[]);

#endif

