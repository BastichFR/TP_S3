#ifndef FACTO_H
#define FACTO_H

unsigned long facto(unsigned long n);

#endif