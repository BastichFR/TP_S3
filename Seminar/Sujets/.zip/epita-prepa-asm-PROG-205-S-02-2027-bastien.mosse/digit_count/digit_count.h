#ifndef DIGIT_COUNT_H
#define DIGIT_COUNT_H

unsigned char digit_count(unsigned long n);

#endif
