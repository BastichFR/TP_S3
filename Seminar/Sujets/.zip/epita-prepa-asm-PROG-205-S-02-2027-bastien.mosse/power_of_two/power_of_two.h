#ifndef POWER_OF_TWO_H
#define POWER_OF_TWO_H

unsigned long power_of_two(unsigned long n);

#endif
