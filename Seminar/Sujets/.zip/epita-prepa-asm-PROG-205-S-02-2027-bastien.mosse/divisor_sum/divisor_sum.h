#ifndef DIVISOR_SUM_H
#define DIVISOR_SUM_H

unsigned long divisor_sum(unsigned long n);

#endif
