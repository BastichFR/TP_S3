#ifndef FIBO_H
#define FIBO_H

unsigned long fibo(unsigned long n);

#endif

