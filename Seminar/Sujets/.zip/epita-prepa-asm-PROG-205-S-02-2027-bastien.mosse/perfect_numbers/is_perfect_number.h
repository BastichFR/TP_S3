#ifndef PERFECT_NUMBER_H
#define PERFECT_NUMBER_H

int is_perfect_number(unsigned long n);

#endif
