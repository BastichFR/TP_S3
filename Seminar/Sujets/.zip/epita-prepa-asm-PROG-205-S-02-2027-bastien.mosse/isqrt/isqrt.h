#ifndef ISQRT_H
#define ISQRT_H

unsigned long isqrt(unsigned long n);

#endif
